#include "reg51.h"

static int count = 0;

unsigned char code Display[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
unsigned char code Seg[] = {0,1,2,3,4,5,6,7};
unsigned char code Led[] = {0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};

void delay(unsigned int num) {
	while(--num);
}

void Int0_Init() {
	EA =1;
	IT0 = 1;
	EX0 = 1;
}

void main() {
	int play;
	P1 = 0x00;
	Int0_Init();
	
	for(;;) {
		play = count / 100;
		P2 = 0;
		P0 = Display[play];
		delay(100);
		play = count / 10 % 10;
		P2 = 1;
		P0 = Display[play];
		delay(100);
		play = count % 10;
		P2 = 2;
		P0 = Display[play];
		delay(100);
		P0 = 0x00;
	}
}


void Int0() interrupt 0 {
	static char i = 0;
	P1 = Led[i];
	++count;
	++i;
	if(i == 8) {
		i = 0;
	}
	delay(50);
}