#include "reg51.h"

unsigned char code Display[] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f};
unsigned char code Seg[] = {0, 1, 2, 3, 4, 5, 6, 7};
unsigned char code Led[] = {0xfe, 0xfd, 0xfb, 0xf7, 0xef, 0xdf, 0xbf, 0x7f};

void Time0Init() {
	TMOD &= 0xF0;
	TMOD |= 0x01;
	
	TH0 = 0x3C;
	TL0 = 0xB0;
	
	ET0 = 1;
	EA = 1;
	TR0 = 1;
}

void main() {
	Time0Init();
	for(;;);
}

void Tim0() interrupt 1 {
	static unsigned char i = 0;
	static unsigned char ledCount = 0;
	static unsigned char segCount = 0;
	static unsigned char displayCount = 0;
	
	TH0 = 0x3C;
	TL0 = 0xB0;
	
	if(i == 10) {
		P1 = Led[ledCount++];
		P2 = Seg[segCount++];
		P0 = Display[displayCount++];
		if(ledCount == 8) ledCount = 0;
		if(segCount == 4) segCount = 0;
		if(displayCount == 10) displayCount = 0;
		i = 0;
	}
	i++;
}
